package net.lingala.zip4j.model.enums;

public enum EncryptionMethod {

  NONE,
  ZIP_STANDARD,
  ZIP_STANDARD_VARIANT_STRONG,
  AES

}
