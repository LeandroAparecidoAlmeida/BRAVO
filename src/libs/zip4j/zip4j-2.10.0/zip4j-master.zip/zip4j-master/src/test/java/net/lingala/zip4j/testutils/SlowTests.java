package net.lingala.zip4j.testutils;

public interface SlowTests {
}
